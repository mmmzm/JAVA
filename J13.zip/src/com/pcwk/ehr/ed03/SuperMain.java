package com.pcwk.ehr.ed03;

public class SuperMain {

	public static void main(String[] args) {
		Child child=new Child();
		child.display();

	}

}
