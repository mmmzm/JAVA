package com.pcwk.ehr.ed03;

public class Parent {
	int age = 23;
}
