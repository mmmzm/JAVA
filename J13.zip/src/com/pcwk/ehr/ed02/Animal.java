package com.pcwk.ehr.ed02;

public class Animal { //extends Object 컴파일러가 추가한다.

	void makeSound() {
		System.out.println("동물이 소리를 내고 있습니다.");
	}
}
