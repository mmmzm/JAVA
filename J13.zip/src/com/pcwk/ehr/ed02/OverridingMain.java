package com.pcwk.ehr.ed02;

public class OverridingMain {

	public static void main(String[] args) {
		Dog dog=new Dog();
		
		dog.makeSound();

	}

}
