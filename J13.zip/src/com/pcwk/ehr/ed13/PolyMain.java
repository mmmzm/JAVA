/**
 * Package Name : com.pcwk.ehr.ed13 <br>
 * Class Name   : PolyMain.java <br>
 * Description  : <br>
 * Modification information :
 *------------------------------------------------
 * 최초 생성일          : 2024-03-27<br>
 *
 *
 *------------------------------------------------
 * author : acorn
 * version: 0.5
 * see    : <br>
 * Copyright (C) by PCWK All right reserved.
 */
package com.pcwk.ehr.ed13;

/**
 * @author acorn
 *
 */
public class PolyMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Tv t=new CaptionTv();//조상 타입의 참조변수로 자손 인스턴스 참조
		

		CaptionTv capTv=new CaptionTv();


	}

}
