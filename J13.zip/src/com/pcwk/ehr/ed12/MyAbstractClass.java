/**
 * Package Name : com.pcwk.ehr.ed12 <br>
 * Class Name   : MyAbstractClass.java <br>
 * Description  : <br>
 * Modification information :
 *------------------------------------------------
 * 최초 생성일          : 2024-03-27<br>
 *
 *
 *------------------------------------------------
 * author : acorn
 * version: 0.5
 * see    : <br>
 * Copyright (C) by PCWK All right reserved.
 */
package com.pcwk.ehr.ed12;


public abstract class MyAbstractClass {//추상 클래스
	
	public abstract  void myAbstractMethod();//추상 메서드:body부분이 없다.
}
