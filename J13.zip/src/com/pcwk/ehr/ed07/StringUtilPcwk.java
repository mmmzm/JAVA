package com.pcwk.ehr.ed07;
import org.apache.commons.lang3.StringUtils;
public class StringUtilPcwk {

	public static void main(String[] args) {
		String result = StringUtils.upperCase("Hello");
		
		System.out.println(result);

	}

}
