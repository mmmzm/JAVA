package com.pcwk.ehr.ed05;

public class MyClass {

	
	
	public static void myStaticMethod() {
		
	}
}
