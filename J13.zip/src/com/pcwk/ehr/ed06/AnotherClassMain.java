package com.pcwk.ehr.ed06;
import static com.pcwk.ehr.ed05.MyClass.myStaticMethod;

public class AnotherClassMain {

	public static void main(String[] args) {
		//MyClass  myClass=new MyClass();
		myStaticMethod();

	}

}
