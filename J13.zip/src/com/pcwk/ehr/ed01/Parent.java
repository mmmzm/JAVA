package com.pcwk.ehr.ed01;

import java.io.IOException;
import java.sql.SQLException;

public class Parent {

	
	void parentMethod() throws IOException, SQLException{
		
	}
}


