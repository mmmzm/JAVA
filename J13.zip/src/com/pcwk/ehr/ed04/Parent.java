package com.pcwk.ehr.ed04;

public class Parent {
	int num;

	public Parent(int num) {

		this.num = num;
	}
	
	
}
